package com.example.myapplication111;

public class TypeReponse {

    String type;





    public TypeReponse(String type) {

        this.type=type;
    }
}
