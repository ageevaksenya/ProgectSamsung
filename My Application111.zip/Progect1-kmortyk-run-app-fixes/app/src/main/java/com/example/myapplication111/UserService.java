package com.example.myapplication111;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Query;

public interface UserService {
    @POST("/")
    Call<TypeReponse> fetchUser(@Query("type") String  type, @Query("name") String name, @Query("email") String email, @Query("password") String password, @Query("image") byte[] image);
    @GET("/")
    Call<List<Securities>> sec(@Query("type") String  type, @Query("table") String table);
    @GET("/")
    Call<List<UsersA>> users(@Query("type") String  type, @Query("table") String table);
    @GET("/")
    Call<MyData> AUser(@Query("type") String  type, @Query("email") String email, @Query("password") String password);
    @GET("/")
    Call<Tk> purchase (@Query("type")String type,@Query("token") String token,@Query("amount") int  amount);
    @GET("/")
    Call<Tk> sale (@Query("type")String type,@Query("token") String token,@Query("amount") int amount);
    @POST("/")
    Call<Tk> photo (@Query("type")String type,@Query("token") String token,@Query("photo") byte[] photo);
    @GET("/")
    Call<Tk> token (@Query("type")String type);
    @GET("/")
    Call<String> price (@Query("type")String type,@Query("name")String name,@Query("comp")String comp);
//    @Multipart

}
