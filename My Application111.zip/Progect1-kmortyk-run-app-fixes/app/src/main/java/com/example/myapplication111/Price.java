package com.example.myapplication111;

import android.os.AsyncTask;

public class Price  extends AsyncTask<Void, Integer, Void> {
    int price;
    int n=10;
    public Price(int price){
        this.price=price;
    }

    @Override
    protected Void doInBackground(Void... voids) {
        while(true){
            price= (int) (price+(Math.random()*((n+n)+1)-n));
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}


