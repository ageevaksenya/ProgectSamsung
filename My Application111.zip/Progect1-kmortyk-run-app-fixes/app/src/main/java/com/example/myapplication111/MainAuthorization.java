package com.example.myapplication111;



import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainAuthorization extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        MainChoice.flag_registr=false;
        setContentView(R.layout.activity_main2);
        TextView textView =  findViewById(R.id.text1);
        textView.setPaintFlags(textView.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);
        Button button1 = findViewById(R.id.btn_filt);
        EditText etEmail =  findViewById(R.id.editTextTextEmailAddress);
        EditText etPassword =  findViewById(R.id.editTextTextPassword);
        ImageButton button2 =  findViewById(R.id.btn_enter);
        button1.setOnClickListener(view -> {
            Intent intent = new Intent(MainAuthorization.this, MainRegistration.class);
            MainAuthorization.this.startActivity(intent);
        });
        button2.setOnClickListener(view -> {

            String type="auntefication";
            String email1 = etEmail.getText().toString();
            String password1 = etPassword.getText().toString();
            Call<MyData> call = MyServer.service.AUser(type, email1, password1);
            call.enqueue(new Callback<MyData>() {
                @Override
                public void onResponse(Call<MyData> call, Response<MyData> response) {
                    if(response.isSuccessful()){
                        MyData myData= response.body();
                        Intent intent = new Intent(MainAuthorization.this, MainChoice.class);
                        MainAuthorization.this.startActivity(intent);
                    }
                    Toast.makeText(MainAuthorization.this, response.body().toString(), Toast.LENGTH_SHORT).show();
                }

                @Override
                public void onFailure(Call<MyData> call, Throwable t) {
                    if (t instanceof IOException) {
                        Toast.makeText(MainAuthorization.this, "сбой сети :( повторите попытку", Toast.LENGTH_SHORT).show();
                    }
                    else {
                        Toast.makeText(MainAuthorization.this, "проблема с конверсией! :(", Toast.LENGTH_SHORT).show();
                    }
                }

            });


        });
    }
}