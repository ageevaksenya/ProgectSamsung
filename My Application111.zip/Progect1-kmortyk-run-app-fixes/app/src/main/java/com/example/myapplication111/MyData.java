package com.example.myapplication111;

public class MyData {
    private static int my_purse;
    static String my_name;
    static byte[] my_image;
    static private String token;
    private String id;

    public void setMy_purse(int my_purse) {
        this.my_purse = my_purse;
    }

    public static int getMy_purse() {
        return my_purse;
    }

    public static String getMy_name() {
        return my_name;
    }

    public byte[] getMy_image() {
        return my_image;
    }

    public void setMy_image(byte[] my_image) {
        this.my_image = my_image;
    }

    public void setMy_name(String my_name) {
        this.my_name = my_name;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public  void setToken(String token) {
        this.token = token;
    }

    public static String getToken() {
        return token;
    }

    public MyData(String my_name, byte[] my_image, int my_purse) {
        this.my_name = my_name;
        this.my_image=my_image;
        this.my_purse=my_purse;
    }
    public MyData() { }
}
