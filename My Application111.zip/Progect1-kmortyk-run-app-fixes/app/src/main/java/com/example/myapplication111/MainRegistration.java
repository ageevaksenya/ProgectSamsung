package com.example.myapplication111;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainRegistration extends AppCompatActivity {
    private ImageButton btnSend;
    private EditText etName;
    private EditText etEmail;
    private EditText Password;
    String res;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        MainChoice.flag_registr = true;
        setContentView(R.layout.activity_main);
        btnSend = findViewById(R.id.btn_registr);
        etName = findViewById(R.id.nameusers);
        Password = findViewById(R.id.editTextTextPassword);
        etEmail = findViewById(R.id.editTextTextEmailAddress);
        btnSend.setOnClickListener((v) -> {
            String type ="registration";
            final Bitmap bitmap =BitmapFactory.decodeResource(getResources(), R.drawable.personimage_round); ;
            ByteArrayOutputStream stream = new ByteArrayOutputStream();
            final Animation animation = AnimationUtils.loadAnimation(this, R.anim.earthquake);
            final View linear =  findViewById(R.id.linear);

            bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
            byte[] byteArray = stream.toByteArray();
            bitmap.recycle();
            Call<TypeReponse> call = MyServer.service.fetchUser(type,etName.getText().toString(),etEmail.getText().toString(),Password.getText().toString(),byteArray);
            call.enqueue(new Callback<TypeReponse>() {
                @Override
                public void onResponse(Call<TypeReponse> call, Response<TypeReponse> response) {
                    if (response.isSuccessful()) {
                        if(!response.body().type.equals("Success")){
                            linear.startAnimation(animation);
                            Toast.makeText(MainRegistration.this, response.body().type, Toast.LENGTH_SHORT).show();
                        }else {
                            MyData.my_name = etName.getText().toString();
                            Intent intent = new Intent(MainRegistration.this, MainChoice.class);
                            MainRegistration.this.startActivity(intent);
                        }
                    }else {
                        Toast.makeText(MainRegistration.this, response.body().toString(), Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onFailure(Call<TypeReponse> call, Throwable t) {
                    if (t instanceof IOException) {
                        Toast.makeText(MainRegistration.this, "сбой сети :( повторите попытку", Toast.LENGTH_SHORT).show();
                    }
                    else {
                        Toast.makeText(MainRegistration.this, "проблема с конверсией! :(", Toast.LENGTH_SHORT).show();
                    }
                }

            });
        });
    }
}